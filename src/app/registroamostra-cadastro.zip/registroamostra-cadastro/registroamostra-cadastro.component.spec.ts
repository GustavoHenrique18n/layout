import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistroAmostraCadastroComponent } from './registroamostra-cadastro.component';

describe('RegistroAmostraCadastroComponent', () => {
  let component: RegistroAmostraCadastroComponent;
  let fixture: ComponentFixture<RegistroAmostraCadastroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegistroAmostraCadastroComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistroAmostraCadastroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
