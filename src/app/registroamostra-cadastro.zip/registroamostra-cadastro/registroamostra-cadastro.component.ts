import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registroamostra-cadastro',
  templateUrl: './registroamostra-cadastro.component.html',
  styleUrls: ['./registroamostra-cadastro.component.css']
})
export class RegistroAmostraCadastroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
